import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    int rodada1Aremesso1 = 0;
    int rodada1Aremesso2 = 0;
    int rodada2Aremesso1 = 0;
    int rodada2Aremesso2 = 0;
    int rodada3Aremesso1 = 0;
    int rodada3Aremesso2 = 0;
    int rodada4Aremesso1 = 0;
    int rodada4Aremesso2 = 0;
    int rodada5Aremesso1 = 0;
    int rodada5Aremesso2 = 0;
    int rodada6Aremesso1 = 0;
    int rodada6Aremesso2 = 0;
    int rodada7Aremesso1 = 0;
    int rodada7Aremesso2 = 0;
    int rodada8Aremesso1 = 0;
    int rodada8Aremesso2 = 0;
    int rodada9Aremesso1 = 0;
    int rodada9Aremesso2 = 0;
    int rodada10Aremesso1 = 0;
    int rodada10Aremesso2 = 0;
    int rodadaBonusAremesso1 = 0;
    int rodadaBonusAremesso2 = 0;
    Scanner teclado = new Scanner (System.in);
    System.out.println("Informe a quantidade de pinos derrubados na rodada 1 arremesso 1");
     rodada1Aremesso1 = teclado.nextInt();
     if (rodada1Aremesso1 < 10){
      System.out.println("Informe a quantidade de pinos derrubados na rodada 1 arremesso 2");
     rodada1Aremesso2 = teclado.nextInt(); 
     }
     System.out.println("Informe a quantidade de pinos derrubados na rodada 2 arremesso 1");
     rodada2Aremesso1 = teclado.nextInt();
     if (rodada2Aremesso1 < 10){
      System.out.println("Informe a quantidade de pinos derrubados na rodada 2 arremesso 2");
     rodada2Aremesso2 = teclado.nextInt(); 
     }
     System.out.println("Informe a quantidade de pinos derrubados na rodada 3 arremesso 1");
     rodada3Aremesso1 = teclado.nextInt();
     if (rodada3Aremesso1 < 10){
      System.out.println("Informe a quantidade de pinos derrubados na rodada 3 arremesso 2");
     rodada3Aremesso2 = teclado.nextInt(); 
     }
     System.out.println("Informe a quantidade de pinos derrubados na rodada 4 arremesso 1");
     rodada4Aremesso1 = teclado.nextInt();
     if (rodada4Aremesso1 < 10){
      System.out.println("Informe a quantidade de pinos derrubados na rodada 4 arremesso 2");
     rodada4Aremesso2 = teclado.nextInt(); 
     }
     System.out.println("Informe a quantidade de pinos derrubados na rodada 5 arremesso 1");
     rodada5Aremesso1 = teclado.nextInt();
     if (rodada5Aremesso1 < 10){
      System.out.println("Informe a quantidade de pinos derrubados na rodada 5 arremesso 2");
     rodada5Aremesso2 = teclado.nextInt(); 
     }
     System.out.println("Informe a quantidade de pinos derrubados na rodada 6 arremesso 1");
     rodada6Aremesso1 = teclado.nextInt();
     if (rodada6Aremesso1 < 10){
      System.out.println("Informe a quantidade de pinos derrubados na rodada 6 arremesso 2");
     rodada6Aremesso2 = teclado.nextInt(); 
     }
     System.out.println("Informe a quantidade de pinos derrubados na rodada 7 arremesso 1");
     rodada7Aremesso1 = teclado.nextInt();
     if (rodada7Aremesso1 < 10){
      System.out.println("Informe a quantidade de pinos derrubados na rodada 7 arremesso 2");
     rodada7Aremesso2 = teclado.nextInt(); 
     }
     System.out.println("Informe a quantidade de pinos derrubados na rodada 8 arremesso 1");
     rodada8Aremesso1 = teclado.nextInt();
     if (rodada8Aremesso1 < 10){
      System.out.println("Informe a quantidade de pinos derrubados na rodada 8 arremesso 2");
     rodada8Aremesso2 = teclado.nextInt(); 
     }
     System.out.println("Informe a quantidade de pinos derrubados na rodada 9 arremesso 1");
     rodada9Aremesso1 = teclado.nextInt();
     if (rodada9Aremesso1 < 10){
      System.out.println("Informe a quantidade de pinos derrubados na rodada 9 arremesso 2");
     rodada9Aremesso2 = teclado.nextInt(); 
     }
     System.out.println("Informe a quantidade de pinos derrubados na rodada 10 arremesso 1");
     rodada10Aremesso1 = teclado.nextInt();
     if (rodada10Aremesso1 < 10){
      System.out.println("Informe a quantidade de pinos derrubados na rodada 10 arremesso 2");
     rodada10Aremesso2 = teclado.nextInt(); 
     }
     else{
       System.out.println("Informe a quantidade de pinos derrubados na rodada bonus arremesso 1");
       rodadaBonusAremesso1 = teclado.nextInt();
       if (rodadaBonusAremesso1 < 10){
      System.out.println("Informe a quantidade de pinos derrubados na rodada bonus arremesso 2");
     rodadaBonusAremesso2 = teclado.nextInt(); 
     }
     }
     if (rodada1Aremesso1 == 10){
       rodada1Aremesso1 += rodada2Aremesso1;
       rodada1Aremesso1 += rodada2Aremesso2;
     }
     if(rodada1Aremesso2 + rodada1Aremesso1 >= 10){
       rodada1Aremesso2 += rodada2Aremesso1;
     }
     if (rodada2Aremesso1 == 10){
       rodada2Aremesso1 += rodada3Aremesso1;
       rodada2Aremesso1 += rodada3Aremesso2;
     }
     if(rodada1Aremesso2 + rodada1Aremesso1 >= 10){
       rodada3Aremesso2 += rodada4Aremesso1;
     }
     if (rodada3Aremesso1 == 10){
       rodada3Aremesso1 += rodada4Aremesso1;
       rodada3Aremesso1 += rodada4Aremesso2;
     }
     if(rodada3Aremesso2 + rodada3Aremesso1 >= 10){
       rodada3Aremesso2 += rodada4Aremesso1;
     }
     if (rodada4Aremesso1 == 10){
       rodada4Aremesso1 += rodada5Aremesso1;
       rodada4Aremesso1 += rodada5Aremesso2;
     }
     if(rodada4Aremesso2 + rodada4Aremesso1 >= 10){
       rodada4Aremesso2 += rodada5Aremesso1;
     }
     if (rodada5Aremesso1 == 10){
       rodada5Aremesso1 += rodada6Aremesso1;
       rodada5Aremesso1 += rodada6Aremesso2;
     }
     if(rodada5Aremesso2 + rodada5Aremesso1 >= 10){
       rodada5Aremesso2 += rodada6Aremesso1;
     }
     if (rodada6Aremesso1 == 10){
       rodada6Aremesso1 += rodada4Aremesso1;
       rodada6Aremesso1 += rodada4Aremesso2;
     }
     if(rodada6Aremesso2 + rodada6Aremesso1 >= 10){
       rodada6Aremesso2 += rodada7Aremesso1;
     }
     if (rodada7Aremesso1 == 10){
       rodada7Aremesso1 += rodada8Aremesso1;
       rodada7Aremesso1 += rodada8Aremesso2;
     }
     if(rodada7Aremesso2 + rodada7Aremesso1 >= 10){
       rodada7Aremesso2 += rodada8Aremesso1;
     }
     if (rodada8Aremesso1 == 10){
       rodada8Aremesso1 += rodada9Aremesso1;
       rodada3Aremesso1 += rodada9Aremesso2;
     }
     if(rodada8Aremesso2 + rodada8Aremesso1 >= 10){
       rodada8Aremesso2 += rodada9Aremesso1;
     }
     if (rodada9Aremesso1 == 10){
       rodada9Aremesso1 += rodada10Aremesso1;
       rodada9Aremesso1 += rodada10Aremesso2;
     }
     if(rodada9Aremesso2 + rodada9Aremesso1 >= 10){
       rodada9Aremesso2 += rodada10Aremesso1;
     }
     if (rodada10Aremesso1 == 10){
       rodada10Aremesso1 += rodadaBonusAremesso1;
       rodada10Aremesso1 += rodadaBonusAremesso2;
     }
     if(rodada10Aremesso2 + rodada10Aremesso1 >= 10){
       rodada10Aremesso2 += rodadaBonusAremesso1;
     }
     int resultadofinal = rodada1Aremesso1 + rodada1Aremesso2 + rodada2Aremesso1 + rodada2Aremesso2 + rodada3Aremesso1 + rodada3Aremesso2 + rodada4Aremesso1 + rodada4Aremesso2 + rodada5Aremesso1 + rodada5Aremesso2 + rodada6Aremesso1 + rodada6Aremesso2 + rodada7Aremesso1 + rodada7Aremesso2 + rodada8Aremesso1 + rodada8Aremesso2 + rodada9Aremesso1 + rodada9Aremesso2 + rodada10Aremesso1 + rodada10Aremesso2 + rodadaBonusAremesso1 + rodadaBonusAremesso2;
     System.out.println("Sua pontuação final é :  "+resultadofinal);
    
  }
}